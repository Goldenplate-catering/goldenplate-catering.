
import crypto from 'crypto';

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'changeme';
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET || 'secret_example';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'ishimweb017@gmail.com';

function signToken(payload) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto.createHmac('sha256', ADMIN_JWT_SECRET).update(header + '.' + body).digest('base64url');
  return `${header}.${body}.${signature}`;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Missing credentials' });
  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    const token = signToken({ email: ADMIN_EMAIL, iat: Date.now() });
    return res.json({ ok: true, token });
  }
  return res.status(401).json({ ok: false, error: 'Invalid credentials' });
}
