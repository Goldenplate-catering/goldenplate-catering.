
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET || 'secret_example';

function verifyToken(token) {
  try {
    const [headerB, bodyB, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', ADMIN_JWT_SECRET).update(headerB + '.' + bodyB).digest('base64url');
    if (expected !== sig) return false;
    const body = JSON.parse(Buffer.from(bodyB, 'base64url').toString('utf8'));
    // token valid for 24 hours
    if (Date.now() - (body.iat || 0) > 24 * 3600 * 1000) return false;
    return true;
  } catch (e) { return false; }
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  const auth = req.headers.authorization || '';
  const parts = auth.split(' ');
  if (parts[0] !== 'Bearer' || !parts[1]) return res.status(401).json({ error: 'Unauthorized' });
  const token = parts[1];
  if (!verifyToken(token)) return res.status(401).json({ error: 'Invalid token' });
  try {
    const { data, error } = await supabase.from('bookings').select('*').order('created_at', { ascending: false });
    if (error) return res.status(500).json({ error: 'Database error' });
    return res.json({ ok: true, bookings: data });
  } catch (e) {
    return res.status(500).json({ error: 'Server error' });
  }
}
