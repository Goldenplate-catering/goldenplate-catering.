
import { createClient } from '@supabase/supabase-js';
import nodemailer from 'nodemailer';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const FROM_EMAIL = process.env.FROM_EMAIL || 'no-reply@goldenplatecatering.com';

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const body = req.body || {};
    const first_name = body.firstName || body.first_name || body.name || '';
    const last_name = body.lastName || body.last_name || '';
    const email = body.email || '';
    const phone = body.phone || '';
    const event_date = body.date || body.event_date || null;
    const guests = body.guests ? (isNaN(Number(body.guests)) ? null : Number(body.guests)) : null;
    const notes = body.notes || body.message || '';

    // insert into supabase
    const { data, error } = await supabase.from('bookings').insert([{
      first_name, last_name, email, phone, event_date, guests, notes
    }]).select();

    if (error) {
      console.error('Supabase insert error', error);
      return res.status(500).json({ error: 'Database error' });
    }

    // optional: send email to admin
    if (process.env.SMTP_HOST && process.env.SMTP_USER) {
      try {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: Number(process.env.SMTP_PORT || 587),
          secure: false,
          auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        });
        await transporter.sendMail({
          from: FROM_EMAIL,
          to: process.env.ADMIN_EMAIL,
          subject: `New booking — ${first_name} ${last_name}`,
          text: `New booking:\n${JSON.stringify(body, null, 2)}`
        });
      } catch (e) {
        console.warn('Email send failed', e.message);
      }
    }

    return res.json({ status: 'ok', booking: data[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
}
